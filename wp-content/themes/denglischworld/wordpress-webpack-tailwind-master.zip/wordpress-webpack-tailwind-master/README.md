# Webpack Setup with Tailwind
This is a super simple Webpack setup to be used with TailwindCSS.

## How To Use It
1. Clone the respository
2. run `npm install`
3. run `npm run start` for development mode
4. run `npm build` for production mode
