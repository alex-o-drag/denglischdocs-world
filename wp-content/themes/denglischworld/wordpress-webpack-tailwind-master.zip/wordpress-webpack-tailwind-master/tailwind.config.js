module.exports = {
  purge: [
    './**/*.php',
    './assets/src/**/*.js'
  ]
}